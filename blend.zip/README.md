# 8/4 + V모델 그룹별 NMAE 블렌딩 인계 패키지

## 바로 사용할 파일

- `submission.csv`: 후처리 전 원본 제출 예측
- `validation_predictions_2024.csv`: 같은 비율을 적용한 2024 검증예측
- `validation_predictions_aug4_reconstructed_2024.csv`: 비율 탐색에 실제 사용한 8/4 재구성 검증예측
- `submission_components.csv`: 모델별 제출 예측과 최종 블렌딩을 함께 기록한 감사 파일
- `blend_weights.csv`: 그룹별 모델 비율
- `validation_metrics.csv`: 그룹/분기별 NMAE·FICR·Score
- `handoff_audit.xlsx`: 인계용 요약 문서
- `manifest.json`, `source_manifest.csv`: 생성조건·원본 경로·해시

## 블렌딩 비율

- Group1: v7 28.5625% + v9.5 43.4935% + 8/4 27.9440%
- Group2: v3 2.5470% + v8 15.6353% + v9.5 40.7779% + 8/4 41.0399%
- Group3: v5 14.6337% + v7 10.0811% + v8 24.5620% + 8/4 50.7232%

## 검증 요약

- 2024 FULL macro NMAE: 0.1179081549
- 2024 FULL macro FICR: 0.4100299956
- 2024 FULL macro Score: 0.6460609203
- 2024 H2 macro NMAE: 0.1108005109

## 후처리 담당자 주의사항

1. `submission.csv`는 디코더/후처리를 적용하지 않은 블렌딩 원본입니다.
2. 출력은 0~설비용량 105%로 제한했습니다.
3. 비율은 2024 Q3+Q4 정답으로 직접 선택되어 검증값이 낙관적일 수 있습니다.
4. 8/4 비율 탐색에는 고정 구조 2024 재구성 검증예측을 사용했습니다. 제출 성분은 8/4 원본 submission입니다.
5. 정확 복원된 8/4 Q3/Q4 행이 생성되면 비율을 다시 계산하는 것이 안전합니다.
